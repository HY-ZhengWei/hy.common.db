package org.hy.common.milvus;

import java.util.List;

import org.hy.common.db.DBTableMetaData;





/**
 * 查询数据库返回的结果。
 * 
 * 主要是通过 MilvusResullt.getDatas() 方法返回的结果。
 *
 * @author      ZhengWei(HY)
 * @createDate  2026-08-02
 * @version     v1.0
 */
public class MilvusData
{
    
    /** 查询返回的结果 */
    private Object          datas;
    
    /** 将数据库结果集转化为Java实例对象的行数(已读取的行数) */
    private long            rowCount;
    
    /** 将数据库结果集转化为Java实例对象的列数(有效列数) */
    private int             colCount;
    
    /** 将数据库结果集转化为Java实例对象的用时时长(单位：毫秒) */
    private long            timeLen;
    
    /** 结果集的字段结构 */
    private DBTableMetaData metaData;
    
    
    
    public MilvusData(Object i_Datas ,long i_RowCount ,int i_ColCount ,long i_TimeLen ,DBTableMetaData i_MetaData)
    {
        this.datas     = i_Datas;
        this.rowCount  = i_RowCount;
        this.colCount  = i_ColCount;
        this.timeLen   = i_TimeLen;
        this.metaData  = i_MetaData;
    }

    
    
    /**
     * 获取：查询返回的结果
     */
    public Object getDatas()
    {
        return datas;
    }


    
    /**
     * 获取：将数据库结果集转化为Java实例对象的行数(已读取的行数)
     */
    public long getRowCount()
    {
        return rowCount;
    }


    
    /**
     * 获取：将数据库结果集转化为Java实例对象的列数(有效列数)
     */
    public int getColCount()
    {
        return colCount;
    }


    
    /**
     * 获取：将数据库结果集转化为Java实例对象的用时时长(单位：毫秒)
     */
    public long getTimeLen()
    {
        return timeLen;
    }


    
    /**
     * 获取：Insert语句影响生成的自增长ID的集合
     */
    @SuppressWarnings("unchecked")
    public List<Integer> getIdentitys()
    {
        return (List<Integer>)datas;
    }



    
    /**
     * 获取：结果集的字段结构
     */
    public DBTableMetaData getMetaData()
    {
        return metaData;
    }
    
}
